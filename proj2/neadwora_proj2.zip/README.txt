Compile with `make`
Run with `./ftserver` and `./ftclient`

Extra Credit:
- multithreaded server
- any file type

Resources used:
https://stackoverflow.com/q/13669474
https://www.geeksforgeeks.org/c-program-list-files-sub-directories-directory/
https://github.com/captainGeech42/CS344/blob/master/otp/common.c#L27 (this is my own GitHub, CS344 OTP assignment)
My chat server/client CS732 proj 1 code